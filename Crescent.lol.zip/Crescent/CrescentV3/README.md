AutoWallhop
© Crescent, 2025

License You are granted a non-exclusive, worldwide, royalty-free license to:

Use, modify, and run this script for personal or commercial purposes.

Distribute or sell this script, including modified versions, without requiring permission or attribution.

Restrictions You may not use this script to violate the terms of service or rules of any game, platform, or software.

You may not use this script for illegal activities or harmful purposes.

Disclaimer This script is provided "as-is", without any warranties or guarantees of any kind, express or implied.

The author is not responsible for any damage, loss, or issues that arise from the use or misuse of this script.

Use this script at your own risk.

Support No official support or updates are guaranteed.

You may modify the script as needed.